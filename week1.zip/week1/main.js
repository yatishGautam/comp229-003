import { halfof } from "./lib.js";
console.log(halfof(84));