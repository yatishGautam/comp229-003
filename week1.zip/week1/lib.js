export function halfof(x){
    return x/2;
}