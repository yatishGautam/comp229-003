export let flag = false;
export function touch() {
flag = true;
}